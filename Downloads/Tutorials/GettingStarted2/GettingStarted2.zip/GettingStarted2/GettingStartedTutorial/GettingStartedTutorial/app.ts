/// <reference path="MyGame.ts" />

var game = new MyGame();