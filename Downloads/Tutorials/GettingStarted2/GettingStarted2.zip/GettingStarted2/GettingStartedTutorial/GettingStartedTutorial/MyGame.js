var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
/// <reference path="Scripts/endgate-0.1.0.d.ts" />
var MyGame = (function (_super) {
    __extends(MyGame, _super);
    function MyGame() {
        var _this = this;
        _super.call(this);
        this._circleSpeed = 200;

        this._circle = new eg.Graphics.Circle(100, 150, 40, "red");

        this._movementController = new eg.MovementControllers.LinearMovementController([this._circle], this._circleSpeed);
        this._inputController = new eg.InputControllers.DirectionalInputController(this.Input.Keyboard, function (direction, startMoving) {
            _this._movementController.Move(direction, startMoving);
        });

        this.Input.Mouse.OnClick.Bind(function (event) {
            _this._movementController.Position = event.Position;
        });

        this.Scene.Add(this._circle);
    }
    MyGame.prototype.Update = function (gameTime) {
        this._movementController.Update(gameTime);
    };
    return MyGame;
})(eg.Game);
//@ sourceMappingURL=MyGame.js.map
