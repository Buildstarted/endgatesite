/// <reference path="Scripts/endgate-0.1.0.d.ts" />

class MyGame extends eg.Game {
    private _circle: eg.Graphics.Circle;
    private _circleSpeed: number = 200;
    private _inputController: eg.InputControllers.DirectionalInputController;
    private _movementController: eg.MovementControllers.LinearMovementController;

    constructor() {
        super();

        this._circle = new eg.Graphics.Circle(100, 150, 40, "red");

        this._movementController = new eg.MovementControllers.LinearMovementController([this._circle], this._circleSpeed);
        this._inputController = new eg.InputControllers.DirectionalInputController(this.Input.Keyboard, (direction: string, startMoving: boolean) => {
            this._movementController.Move(direction, startMoving);
        });

        this.Input.Mouse.OnClick.Bind((event: eg.Input.IMouseClickEvent) => {
            this._movementController.Position = event.Position;
        });
        
        this.Scene.Add(this._circle);
    }

    public Update(gameTime: eg.GameTime): void {
        this._movementController.Update(gameTime);
    }
}