/// <reference path="MyGame.ts" />
var game = new MyGame();
//@ sourceMappingURL=app.js.map
