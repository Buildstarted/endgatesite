var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
/// <reference path="Scripts/endgate-0.1.0.d.ts" />
var MyGame = (function (_super) {
    __extends(MyGame, _super);
    function MyGame() {
        _super.call(this);

        this._circle = new eg.Graphics.Circle(100, 150, 40, "red");

        this.Scene.Add(this._circle);
    }
    MyGame.prototype.Update = function (gameTime) {
        // Move the circle to the right at 200 pixels per second
        this._circle.Position.X += gameTime.Elapsed.Seconds * 200;
    };
    return MyGame;
})(eg.Game);
//@ sourceMappingURL=MyGame.js.map
